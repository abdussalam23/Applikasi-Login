<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>frofile.com</title>
</head>

<body style="background:darkgray;">
    <div style="color:rgb(252, 252, 252); padding: 30px; font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">
        <h1 style="color: blue;">Selamat Datang di Salman chanel</h1>
        <h3>Demonstrasi Google App Engine</h3>
    </div>
</body>

</html>